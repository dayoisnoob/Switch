import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';

import { LabelController } from '../controllers/labels.controller';
import {
  validateInput,
  validateUrlParams,
} from '../middleware/validation.middleware';
import {
  requireWorkspaceMember,
  requireWorkspaceRole,
} from '../middleware/workspace.middleware';
import { asyncHandler } from '../utils/async-handler';
import {
  createLabelSchema,
  updateLabelSchema,
} from '../validations/labels.validation';
import { paramsSchema } from '../validations/urlParams.validation';

const router = Router({ mergeParams: true });

router.post(
  '/',
  authenticate,
  validateUrlParams(paramsSchema),
  validateInput(createLabelSchema),
  requireWorkspaceMember,
  requireWorkspaceRole(['Owner', 'Admin']),
  asyncHandler(LabelController.createLabel)
);

router.get(
  '/',
  authenticate,
  validateUrlParams(paramsSchema),
  requireWorkspaceMember,
  asyncHandler(LabelController.listLabels)
);

router.patch(
  '/:labelId',
  authenticate,
  validateUrlParams(paramsSchema),
  validateInput(updateLabelSchema),
  requireWorkspaceMember,
  requireWorkspaceRole(['Owner', 'Admin']),
  asyncHandler(LabelController.updateLabel)
);

router.delete(
  '/:labelId',
  authenticate,
  validateUrlParams(paramsSchema),
  requireWorkspaceMember,
  requireWorkspaceRole(['Owner', 'Admin']),
  asyncHandler(LabelController.deleteLabel)
);

export default router;
