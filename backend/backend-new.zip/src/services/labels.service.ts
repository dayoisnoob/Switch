import { and, eq, ne } from 'drizzle-orm';
import { db } from '../config/db';
import { cardLabelsTable, cardsTable, labelsTable } from '../db';
import { ApiError } from '../utils/api-response';
import type {
  CreateLabelType,
  UpdateLabelType,
} from '../validations/labels.validation';
import { emitBoardEvent } from '../socket/emitter';

export class LabelService {
  static async createLabel(
    userId: string,
    actorName: string,
    workspaceId: string,
    data: CreateLabelType
  ) {
    const { name, colour, boardId } = data;

    const [existing] = await db
      .select({ id: labelsTable.id })
      .from(labelsTable)
      .where(
        and(
          eq(labelsTable.name, name),
          eq(labelsTable.workspaceId, workspaceId)
        )
      )
      .limit(1);

    if (existing)
      throw new ApiError(
        409,
        `Label with name '${name}' already exists in the workspace`
      );

    const [label] = await db
      .insert(labelsTable)
      .values({
        workspaceId,
        name,
        colour,
      })
      .returning();

    if (!label)
      throw new ApiError(500, 'Error creating label. Please try again.');

    if (boardId) {
      emitBoardEvent(boardId, 'label:created', {
        label,
        actorId: userId,
        actorName,
      });
    }

    return {
      id: label.id,
      name: label.name,
      colour: label.colour,
    };
  }

  static async listLabels(workspaceId: string) {
    const labels = await db
      .select({
        id: labelsTable.id,
        name: labelsTable.name,
        colour: labelsTable.colour,
      })
      .from(labelsTable)
      .where(eq(labelsTable.workspaceId, workspaceId));

    return labels;
  }

  static async updateLabel(
    workspaceId: string,
    labelId: string,
    data: UpdateLabelType
  ) {
    const { name, colour } = data;

    if (name) {
      const [sameName] = await db
        .select({ id: labelsTable.id })
        .from(labelsTable)
        .where(
          and(
            eq(labelsTable.name, name),
            eq(labelsTable.workspaceId, workspaceId),
            ne(labelsTable.id, labelId)
          )
        )
        .limit(1);

      if (sameName)
        throw new ApiError(
          409,
          `Label with name '${name}' already exists in the workspace`
        );
    }

    const [updatedLabel] = await db
      .update(labelsTable)
      .set({
        ...(name !== undefined && { name }),
        ...(colour !== undefined && { colour }),
      })
      .where(eq(labelsTable.id, labelId))
      .returning();

    if (!updatedLabel)
      throw new ApiError(500, 'Error updating label. Please try again.');

    return updatedLabel;
  }

  static async deleteLabel(
    userId: string,
    actorName: string,
    labelId: string,
    boardId: string,
    workspaceId: string
  ) {
    const [deletedlabel] = await db
      .delete(labelsTable)
      .where(
        and(
          eq(labelsTable.id, labelId),
          eq(labelsTable.workspaceId, workspaceId)
        )
      )
      .returning();

    if (!deletedlabel)
      throw new ApiError(500, 'Error deleting label. Please try again.');

    emitBoardEvent(boardId, 'label:deleted', {
      labelId: deletedlabel.id,
      labelName: deletedlabel.name,
      actorId: userId,
      actorName,
    });

    return deletedlabel;
  }
}
